<?php
date_default_timezone_set('Africa/Nairobi');
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt');
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = htmlspecialchars($_POST['name']);
    $email   = htmlspecialchars($_POST['email']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    // Your email
    $adminEmail = "care@royaltech254.co.ke";

    $mail = new PHPMailer(true);
    $mail->SMTPDebug = 2; // or 3 for more detail
    $mail->Debugoutput = 'html';


    try {
        // SMTP settings
        $mail->isSMTP();
        $mail->Host       = 'mail.royaltech254.co.ke';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'care@royaltech254.co.ke';
        $mail->Password   = 'Oscar+254';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Send mail to admin
        $mail->setFrom('care@royaltech254.co.ke', 'NextGen Royal Tech Inc.');
        $mail->addAddress($adminEmail);
        $mail->addReplyTo($email, $name);

        $mail->isHTML(true);
        $mail->Subject = "New Contact Form Message: $subject";
        $mail->Body    = "
            <h2>New Message from Christmas Piano </h2>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Subject:</strong> $subject</p>
            <p><strong>Message:</strong><br>$message</p>
            <hr>
            <p>Sent on " . date('Y-m-d H:i:s') . "</p>
        ";

        $mail->send();

        // Now send a copy to the user
        $mail->clearAddresses();
        $mail->addAddress($email, $name);
        $mail->Subject = "Thank You for Contacting Us.";
        $mail->Body    = "
            <p>Hi <strong>$name</strong>,</p>
            <p>Thank you for reaching out! We’ve received your message and will get back to you soon.</p>
            <p><em>Your message:</em><br>$message</p>
            <br>
            <p>Best regards,<br>
            <strong>NextGen Royal Tech Inc. 👑</strong><br>
            🌐 <a href='https://royaltech254.co.ke'>royaltech254.co.ke</a></p>
        ";
        $mail->send();

        echo "success";
    } catch (Exception $e) {
        echo "Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo "Invalid request.";
}
